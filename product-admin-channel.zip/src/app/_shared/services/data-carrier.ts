import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})

export class DataCarrier {
  carrier: any = {};
  private static _instance: DataCarrier = new DataCarrier();
  constructor() {
    DataCarrier._instance = this;

  }

  public static getInstance(): DataCarrier {
    return DataCarrier._instance;
  }

  setCarrier(carrierName, carrierValue) {
    this.carrier[carrierName] = carrierValue;
  }

  getCarrier(carrierName) {
    if (this.carrier[carrierName])
      return this.carrier[carrierName];
  }

}