export class ProductModel {
    imageSource?: string;
    id?: string;
    price?: number;
    isDeleted?: boolean;
    isRemoved?: boolean;
    description?: string;
    isLiked?: boolean;
    showItem?: boolean;
    noOfLikes?: number;
    productName?: string;
    category?: string;
    rating?: number;
    isStockAvailable?: boolean;
    constructor() {
        this.showItem = true;
        this.isDeleted = false;
        this.isRemoved = false;
        this.isLiked = false;
        this.noOfLikes = 0;
        this.rating = 0;
        this.isStockAvailable = false;
    }
}