import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.scss']
})
export class SideMenuComponent {
  openNav: boolean = false;
  menuItems: Array<any>;
  jsonURL: string;
  constructor(private http: HttpClient, private router: Router) {
    this.jsonURL = "assets/json/menu-list.json"
    this.getMenuConfig();
  }
  getMenuConfig() {
    this.getJSON().subscribe(data => {
      this.menuItems = data.menuItems;
    });
  }
  public getJSON(): Observable<any> {
    return this.http.get(this.jsonURL);
  }
  menuSelected(item) {
    this.router.navigate([item.route]);
    this.openNav = false;
  }
  openCloseNav() {
    this.openNav = !this.openNav;
  }
}
