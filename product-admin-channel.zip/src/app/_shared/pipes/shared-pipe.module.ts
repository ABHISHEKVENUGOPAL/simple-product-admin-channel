import { ModuleWithProviders, NgModule } from '@angular/core';
import { ListFilterPipe } from './list-filter';

@NgModule({
  imports: [
   
  ],
  declarations: [ 
    
  ],
  exports: [
    
  ]
})
export class SharedPipeModule {
  }