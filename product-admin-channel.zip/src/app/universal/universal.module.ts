import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UniversalRoutingModule } from './universal-routing.module';
import { UniversalComponent } from './universal-landing/universal-landing.component';
import { ProductsComponent } from './products/products.component';
import { HttpClientModule } from '@angular/common/http';
import { SideMenuComponent } from '../_shared/components/side-menu/side-menu.component';
import { TrashComponent } from './trash/trash.component';
import { ProductsDetailsComponent } from './product-details/products-details.component';
import { NgxImageZoomModule } from 'ngx-image-zoom';
import { AddProductsComponent } from './add-product/add-products.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ListFilterPipe } from '../_shared/pipes/list-filter';



@NgModule({
  declarations: [UniversalComponent, AddProductsComponent, ProductsComponent, ProductsDetailsComponent,
    TrashComponent, SideMenuComponent, ListFilterPipe],
  imports: [
    CommonModule,
    UniversalRoutingModule,
    HttpClientModule,
    NgxImageZoomModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class UniversalModule { }
