import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductModel } from 'src/app/_shared/models/product-model';
import { DataCarrier } from 'src/app/_shared/services/data-carrier';

@Component({
  selector: 'app-trash',
  templateUrl: './trash.component.html',
  styleUrls: ['./trash.component.scss']
})
export class TrashComponent implements OnInit, OnDestroy {
  trashList: Array<ProductModel>
  dataCarrier: DataCarrier;
  constructor(private router: Router) {
    this.dataCarrier = DataCarrier.getInstance();
    this.getProductList();
  }
  getProductList() {
    this.trashList = JSON.parse(sessionStorage.getItem('productList'));
  }
  ngOnInit(): void {
  }
  
  restoreItem(item, index) {
    this.trashList[index].isRemoved = false;
  }
  deleteItem(item, index: number) {
    this.trashList.splice(index, 1);
  }
  ngOnDestroy() {
    sessionStorage.setItem('productList', JSON.stringify(this.trashList));
  }
}
