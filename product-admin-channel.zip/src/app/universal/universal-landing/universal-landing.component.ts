import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-universal',
  templateUrl: './universal-landing.component.html',
  styleUrls: ['./universal-landing.component.scss']
})
export class UniversalComponent implements OnInit {
  jsonURL: string;
  constructor(private http: HttpClient) {
    this.jsonURL = "assets/json/product-list.json"
    this.getJSONFile();
  }
  getJSONFile() {
    this.getJSON().subscribe(data => {
      this.setSessionData(data.productList);
    });
  }
  public getJSON(): Observable<any> {
    return this.http.get(this.jsonURL);
  }
  setSessionData(data) {
    sessionStorage.setItem('productList', JSON.stringify(data));
  }
  ngOnInit(): void {
  }

}
