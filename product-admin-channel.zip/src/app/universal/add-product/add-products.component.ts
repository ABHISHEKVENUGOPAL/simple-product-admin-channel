import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormGroup, FormArray, FormBuilder,
  Validators, ReactiveFormsModule
} from '@angular/forms';
import { Router } from '@angular/router';
import { ProductModel } from 'src/app/_shared/models/product-model';
@Component({
  selector: 'app-add-products',
  templateUrl: './add-products.component.html',
  styleUrls: ['./add-products.component.scss']
})
export class AddProductsComponent implements OnInit {
  productList: Array<ProductModel>
  registerForm: FormGroup;
  submitted = false;
  productDetails: ProductModel;
  constructor(
    private formBuilder: FormBuilder,
    private cd: ChangeDetectorRef,
    private router: Router
  ) {
    this.productDetails = new ProductModel()
  }
  ngOnInit(): void {
    const URLregEx = "(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?";
    this.registerForm = this.formBuilder.group({
      title: ["", Validators.required],
      description: ["", Validators.required],
      price: ["", Validators.required],
      rating: ["", Validators.required],
      availability: ["inStock", Validators.required],
      id: ["", Validators.required],
      imageURL: ["", [Validators.required, Validators.pattern(URLregEx)]]
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.registerForm.controls;
  }

  onSubmit() {
    this.cd.markForCheck();
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
    this.mapToModel();
    this.productList = JSON.parse(sessionStorage.getItem('productList'));
    const isUpdate = this.productList.findIndex((item) => (item.id === this.productDetails.id)) >= 0;
    if (isUpdate) {
      this.productList[this.productList.findIndex((item) => (item.id === this.productDetails.id))] = this.productDetails;
    } else {
      this.productList.push(this.productDetails);
    }
    this.updateList();
  }
  updateList() {
    sessionStorage.setItem('productList', JSON.stringify(this.productList));
    this.router.navigate(['products']);
  }
  mapToModel() {
    this.productDetails.id = this.registerForm.value.id;
    this.productDetails.productName = this.registerForm.value.title;
    this.productDetails.description = this.registerForm.value.description;
    this.productDetails.price = this.registerForm.value.price;
    this.productDetails.rating = this.registerForm.value.rating;
    this.productDetails.isStockAvailable = this.registerForm.value.availability === "inStock";
    this.productDetails.imageSource = this.registerForm.value.imageURL;
  }
}

