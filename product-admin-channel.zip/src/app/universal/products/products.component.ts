import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductModel } from 'src/app/_shared/models/product-model';
import { DataCarrier } from 'src/app/_shared/services/data-carrier';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit, OnDestroy {
  productList: Array<ProductModel>
  productListBackUp: Array<ProductModel>
  dataCarrier: DataCarrier;
  searchModel: string;
  constructor(public router: Router) {
    this.dataCarrier = DataCarrier.getInstance();
    this.getProductList();
    this.searchModel = "";
  }

  getProductList() {
    this.productList = JSON.parse(sessionStorage.getItem('productList'));
    this.productListBackUp = JSON.parse(sessionStorage.getItem('productList'));
    this.productList.forEach(element => {
      element.showItem = true;
    });
  }
  checkedChange(event, type) {
    this.productList.forEach(element => {
      if (element.isStockAvailable && type === 'instock') {
        element.showItem = event.currentTarget.checked;
      } else if (!element.isStockAvailable && type === 'outstock') {
        element.showItem = event.currentTarget.checked;
      }
    });
  }
  ngOnInit(): void {

  }
  ngOnDestroy() {
    sessionStorage.setItem('productList', JSON.stringify(this.productList));
  }
  showDetails(item) {
    this.dataCarrier.setCarrier('detailsItem', item);
    this.router.navigate(['details']);
  }
  removeItem(item, index) {
    if (confirm("Are you sure you want to delete?"))
      this.productList[index].isRemoved = true;
  }
  likeItem(item, index) {
    this.productList[index].isLiked = !(this.productList[index].isLiked);
    this.productList[index].noOfLikes = this.productList[index].isLiked ? (this.productList[index].noOfLikes + 1) : (this.productList[index].noOfLikes - 1)

  }
  addProduct() {
    this.router.navigate(['addproduct']);
  }
}
