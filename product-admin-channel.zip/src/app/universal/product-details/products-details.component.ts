import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ProductModel } from 'src/app/_shared/models/product-model';
import { DataCarrier } from 'src/app/_shared/services/data-carrier';

@Component({
  selector: 'app-products-details',
  templateUrl: './products-details.component.html',
  styleUrls: ['./products-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductsDetailsComponent implements OnInit {
  dataCarrier: DataCarrier;
  productDetails: ProductModel;
  constructor(public router: Router) {
    this.dataCarrier = DataCarrier.getInstance();
    this.productDetails = this.dataCarrier.getCarrier('detailsItem');
  }
  backAction() {
    this.router.navigate(['products']);
  }
  ngOnInit(): void {
  } 
}
