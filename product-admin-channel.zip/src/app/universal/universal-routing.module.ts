import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddProductsComponent } from './add-product/add-products.component';
import { ProductsDetailsComponent } from './product-details/products-details.component';
import { ProductsComponent } from './products/products.component';
import { TrashComponent } from './trash/trash.component';
import { UniversalComponent } from './universal-landing/universal-landing.component';

const routes: Routes = [
  {
    path: '', component: UniversalComponent,
    children: [
      { path: '', redirectTo: 'products', pathMatch: 'prefix' },
      { path: 'products', component: ProductsComponent },
      { path: 'details', component: ProductsDetailsComponent },
      { path: 'trash', component: TrashComponent },
      { path: 'addproduct', component: AddProductsComponent }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UniversalRoutingModule { }
